/*  ~*~*~Matrix Meta-Compiled File~*~*~  */

package com.williespetstore.app;

import java.util.*;
import net.unconventionalthinking.lang.*;
import net.unconventionalthinking.matrix.symbols.*;
import net.unconventionalthinking.exceptions.*; 

public class AppSymbols_DescTagName { 

	//  Single Symbols:
	public static DescriptorTagName SCHEMA;
	public static final int SCHEMA$_ID_$ = 47;
	public static DescriptorTagName MATRIX;
	public static final int MATRIX$_ID_$ = 48;
	public static DescriptorTagName DESCRIPTOR;
	public static final int DESCRIPTOR$_ID_$ = 49;
	public static DescriptorTagName ITEM;
	public static final int ITEM$_ID_$ = 50;
	public static DescriptorTagName FIELD;
	public static final int FIELD$_ID_$ = 51;
	public static DescriptorTagName NAMES;
	public static final int NAMES$_ID_$ = 52;
	public static DescriptorTagName TYPES;
	public static final int TYPES$_ID_$ = 53;
	public static DescriptorTagName DESC;
	public static final int DESC$_ID_$ = 54;
	public static DescriptorTagName DEFAULTS;
	public static final int DEFAULTS$_ID_$ = 55;
	public static DescriptorTagName TEST;
	public static final int TEST$_ID_$ = 56;
	public static DescriptorTagName IsPersistentMatrix;
	public static final int IsPersistentMatrix$_ID_$ = 57;
	public static DescriptorTagName net;
	public static final int net$_ID_$ = 58;
	public static DescriptorTagName unconventionalthinking;
	public static final int unconventionalthinking$_ID_$ = 59;
	public static DescriptorTagName matrix;
	public static final int matrix$_ID_$ = 60;
	public static DescriptorTagName schema;
	public static final int schema$_ID_$ = 61;
	public static DescriptorTagName WEB;
	public static final int WEB$_ID_$ = 62;
	public static DescriptorTagName FORM;
	public static final int FORM$_ID_$ = 63;
	public static DescriptorTagName BASE;
	public static final int BASE$_ID_$ = 64;
	public static DescriptorTagName STANDARD;
	public static final int STANDARD$_ID_$ = 65;
	public static DescriptorTagName SCHEMA$95$FOR$95$$95$SCHEMA$95$FOR$95$SCHEMA;
	public static final int SCHEMA$95$FOR$95$$95$SCHEMA$95$FOR$95$SCHEMA$_ID_$ = 66;
	public static DescriptorTagName SCHEMA$95$FOR$95$SCHEMA;
	public static final int SCHEMA$95$FOR$95$SCHEMA$_ID_$ = 67;
	public static DescriptorTagName MATRIXPROG;
	public static final int MATRIXPROG$_ID_$ = 76;
	public static DescriptorTagName PERSISTENCE;
	public static final int PERSISTENCE$_ID_$ = 77;
	public static DescriptorTagName SETTINGS;
	public static final int SETTINGS$_ID_$ = 78;
	public static DescriptorTagName com;
	public static final int com$_ID_$ = 139;
	public static DescriptorTagName williespetstore;
	public static final int williespetstore$_ID_$ = 140;
	public static DescriptorTagName News;
	public static final int News$_ID_$ = 143;
	public static DescriptorTagName Schema;
	public static final int Schema$_ID_$ = 144;
	public static DescriptorTagName NEWS;
	public static final int NEWS$_ID_$ = 154;
	public static DescriptorTagName NewsSectionName;
	public static final int NewsSectionName$_ID_$ = 156;
	public static DescriptorTagName STORY;
	public static final int STORY$_ID_$ = 160;
	public static DescriptorTagName StoryDate;
	public static final int StoryDate$_ID_$ = 164;
	public static DescriptorTagName Title;
	public static final int Title$_ID_$ = 165;
	public static DescriptorTagName StoryContent;
	public static final int StoryContent$_ID_$ = 166;
	public static DescriptorTagName unconventional;
	public static final int unconventional$_ID_$ = 167;
	public static DescriptorTagName persistence;
	public static final int persistence$_ID_$ = 168;
	public static DescriptorTagName WilliesPetstore;
	public static final int WilliesPetstore$_ID_$ = 418;
	public static DescriptorTagName Content;
	public static final int Content$_ID_$ = 419;
	public static DescriptorTagName app;
	public static final int app$_ID_$ = 432;
	public static DescriptorTagName org;
	public static final int org$_ID_$ = 434;
	public static DescriptorTagName apache;
	public static final int apache$_ID_$ = 435;
	public static DescriptorTagName jsp;
	public static final int jsp$_ID_$ = 436;
	public static DescriptorTagName newsStoryDesc;
	public static final int newsStoryDesc$_ID_$ = 442;


	//  MultiPart Symbols:
	public static DescriptorTagName FIELD$__$NAMES;
	public static final int FIELD$__$NAMES$_ID_$ = 346;
	public static DescriptorTagName FIELD$__$TYPES;
	public static final int FIELD$__$TYPES$_ID_$ = 347;
	public static DescriptorTagName FIELD$__$DESC;
	public static final int FIELD$__$DESC$_ID_$ = 348;
	public static DescriptorTagName FIELD$__$DEFAULTS;
	public static final int FIELD$__$DEFAULTS$_ID_$ = 349;
	public static DescriptorTagName MATRIX$__$BASE;
	public static final int MATRIX$__$BASE$_ID_$ = 351;
	public static DescriptorTagName MATRIX$__$STANDARD;
	public static final int MATRIX$__$STANDARD$_ID_$ = 352;
	public static DescriptorTagName MATRIXPROG$__$PERSISTENCE;
	public static final int MATRIXPROG$__$PERSISTENCE$_ID_$ = 354;
	public static DescriptorTagName MATRIXPROG$__$PERSISTENCE$__$SETTINGS;
	public static final int MATRIXPROG$__$PERSISTENCE$__$SETTINGS$_ID_$ = 355;
	public static DescriptorTagName net$__$unconventionalthinking;
	public static final int net$__$unconventionalthinking$_ID_$ = 357;
	public static DescriptorTagName net$__$unconventionalthinking$__$matrix;
	public static final int net$__$unconventionalthinking$__$matrix$_ID_$ = 358;
	public static DescriptorTagName net$__$unconventionalthinking$__$matrix$__$schema;
	public static final int net$__$unconventionalthinking$__$matrix$__$schema$_ID_$ = 359;
	public static DescriptorTagName WEB$__$FORM;
	public static final int WEB$__$FORM$_ID_$ = 361;
	public static DescriptorTagName com$__$williespetstore;
	public static final int com$__$williespetstore$_ID_$ = 363;
	public static DescriptorTagName News$__$Schema;
	public static final int News$__$Schema$_ID_$ = 365;
	public static DescriptorTagName NEWS$__$STORY;
	public static final int NEWS$__$STORY$_ID_$ = 367;
	public static DescriptorTagName net$__$unconventional;
	public static final int net$__$unconventional$_ID_$ = 368;
	public static DescriptorTagName net$__$unconventional$__$persistence;
	public static final int net$__$unconventional$__$persistence$_ID_$ = 369;
	public static DescriptorTagName WilliesPetstore$__$Content;
	public static final int WilliesPetstore$__$Content$_ID_$ = 421;
	public static DescriptorTagName com$__$williespetstore$__$app;
	public static final int com$__$williespetstore$__$app$_ID_$ = 433;
	public static DescriptorTagName org$__$apache;
	public static final int org$__$apache$_ID_$ = 438;
	public static DescriptorTagName org$__$apache$__$jsp;
	public static final int org$__$apache$__$jsp$_ID_$ = 439;


	//  Initializer for Symbols:
	public static boolean have_Intialized = false;



	static void initialize(SymbolControl symbol_Control) throws Exception_InvalidArgumentPassed_Null, Exception_InvalidArgumentPassed,
		Exception_SymbolCreation, Exception_MultiPartSymbolAccess, Exception_MultiPartSymbolCreation, Exception_MultiPartSymbolCreationOrAccess {
		initialize(symbol_Control, false);
	}

	/**
	 * If you set have_ParentAppControl to true, then the symbolControl you pass in should be from a parent AppControl (which means this class
	 * and all of the other app control classes for this application context are probably in a jar, being used by a parent application. <p>
	 *
	 * What this means is that all the ID fields for this class are INCORRECT!! The Id's for symbols will not be hard coded, but set dynamically.<br>
	 * What this also means is that for right now, jar files can not have embedded matrix classes methods with matrix accesses that are called from
	 * a parent application (because matrix access uses these id's).
	 */
	static void initialize(SymbolControl symbol_Control, boolean have_ParentAppControl) throws Exception_InvalidArgumentPassed_Null, Exception_InvalidArgumentPassed,
			Exception_SymbolCreation, Exception_MultiPartSymbolAccess, Exception_MultiPartSymbolCreation, Exception_MultiPartSymbolCreationOrAccess {

		SymbolControl symbolControl = symbol_Control;
		Symbol_Single_Factory singleSymbol_Factory = symbolControl.singleSymbol_Factory;
		Symbol_MultiPart_Factory multiPartSymbol_Factory = symbolControl.multiPartSymbol_Factory;

		//  Multipart-Symbol related variables:
		List<Symbol_Single> newlyCreatedSymbols = new ArrayList<Symbol_Single>();
		Boolean_Mutable have_Created_New_MultiPartSymbol = new Boolean_Mutable(false);
		int creation_StartLevel = 0;
		boolean creation_Has_StaticVersion = true;

		List<String> symbolStrings = null;


		//  Single Symbols _________________________________________________________________________

		SCHEMA = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("SCHEMA", true) :
				singleSymbol_Factory.createNew_DescTagName("SCHEMA", 47, true, null);
		MATRIX = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("MATRIX", true) :
				singleSymbol_Factory.createNew_DescTagName("MATRIX", 48, true, null);
		DESCRIPTOR = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("DESCRIPTOR", true) :
				singleSymbol_Factory.createNew_DescTagName("DESCRIPTOR", 49, true, null);
		ITEM = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("ITEM", true) :
				singleSymbol_Factory.createNew_DescTagName("ITEM", 50, true, null);
		FIELD = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("FIELD", true) :
				singleSymbol_Factory.createNew_DescTagName("FIELD", 51, true, null);
		NAMES = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("NAMES", true) :
				singleSymbol_Factory.createNew_DescTagName("NAMES", 52, true, null);
		TYPES = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("TYPES", true) :
				singleSymbol_Factory.createNew_DescTagName("TYPES", 53, true, null);
		DESC = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("DESC", true) :
				singleSymbol_Factory.createNew_DescTagName("DESC", 54, true, null);
		DEFAULTS = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("DEFAULTS", true) :
				singleSymbol_Factory.createNew_DescTagName("DEFAULTS", 55, true, null);
		TEST = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("TEST", true) :
				singleSymbol_Factory.createNew_DescTagName("TEST", 56, true, null);
		IsPersistentMatrix = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("IsPersistentMatrix", true) :
				singleSymbol_Factory.createNew_DescTagName("IsPersistentMatrix", 57, true, null);
		net = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("net", true) :
				singleSymbol_Factory.createNew_DescTagName("net", 58, true, null);
		unconventionalthinking = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("unconventionalthinking", true) :
				singleSymbol_Factory.createNew_DescTagName("unconventionalthinking", 59, true, null);
		matrix = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("matrix", true) :
				singleSymbol_Factory.createNew_DescTagName("matrix", 60, true, null);
		schema = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("schema", true) :
				singleSymbol_Factory.createNew_DescTagName("schema", 61, true, null);
		WEB = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("WEB", true) :
				singleSymbol_Factory.createNew_DescTagName("WEB", 62, true, null);
		FORM = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("FORM", true) :
				singleSymbol_Factory.createNew_DescTagName("FORM", 63, true, null);
		BASE = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("BASE", true) :
				singleSymbol_Factory.createNew_DescTagName("BASE", 64, true, null);
		STANDARD = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("STANDARD", true) :
				singleSymbol_Factory.createNew_DescTagName("STANDARD", 65, true, null);
		SCHEMA$95$FOR$95$$95$SCHEMA$95$FOR$95$SCHEMA = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("SCHEMA_FOR__SCHEMA_FOR_SCHEMA", true) :
				singleSymbol_Factory.createNew_DescTagName("SCHEMA_FOR__SCHEMA_FOR_SCHEMA", 66, true, null);
		SCHEMA$95$FOR$95$SCHEMA = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("SCHEMA_FOR_SCHEMA", true) :
				singleSymbol_Factory.createNew_DescTagName("SCHEMA_FOR_SCHEMA", 67, true, null);
		MATRIXPROG = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("MATRIXPROG", true) :
				singleSymbol_Factory.createNew_DescTagName("MATRIXPROG", 76, true, null);
		PERSISTENCE = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("PERSISTENCE", true) :
				singleSymbol_Factory.createNew_DescTagName("PERSISTENCE", 77, true, null);
		SETTINGS = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("SETTINGS", true) :
				singleSymbol_Factory.createNew_DescTagName("SETTINGS", 78, true, null);
		com = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("com", true) :
				singleSymbol_Factory.createNew_DescTagName("com", 139, true, null);
		williespetstore = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("williespetstore", true) :
				singleSymbol_Factory.createNew_DescTagName("williespetstore", 140, true, null);
		News = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("News", true) :
				singleSymbol_Factory.createNew_DescTagName("News", 143, true, null);
		Schema = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("Schema", true) :
				singleSymbol_Factory.createNew_DescTagName("Schema", 144, true, null);
		NEWS = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("NEWS", true) :
				singleSymbol_Factory.createNew_DescTagName("NEWS", 154, true, null);
		NewsSectionName = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("NewsSectionName", true) :
				singleSymbol_Factory.createNew_DescTagName("NewsSectionName", 156, true, null);
		STORY = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("STORY", true) :
				singleSymbol_Factory.createNew_DescTagName("STORY", 160, true, null);
		StoryDate = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("StoryDate", true) :
				singleSymbol_Factory.createNew_DescTagName("StoryDate", 164, true, null);
		Title = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("Title", true) :
				singleSymbol_Factory.createNew_DescTagName("Title", 165, true, null);
		StoryContent = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("StoryContent", true) :
				singleSymbol_Factory.createNew_DescTagName("StoryContent", 166, true, null);
		unconventional = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("unconventional", true) :
				singleSymbol_Factory.createNew_DescTagName("unconventional", 167, true, null);
		persistence = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("persistence", true) :
				singleSymbol_Factory.createNew_DescTagName("persistence", 168, true, null);
		WilliesPetstore = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("WilliesPetstore", true) :
				singleSymbol_Factory.createNew_DescTagName("WilliesPetstore", 418, true, null);
		Content = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("Content", true) :
				singleSymbol_Factory.createNew_DescTagName("Content", 419, true, null);
		app = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("app", true) :
				singleSymbol_Factory.createNew_DescTagName("app", 432, true, null);
		org = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("org", true) :
				singleSymbol_Factory.createNew_DescTagName("org", 434, true, null);
		apache = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("apache", true) :
				singleSymbol_Factory.createNew_DescTagName("apache", 435, true, null);
		jsp = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("jsp", true) :
				singleSymbol_Factory.createNew_DescTagName("jsp", 436, true, null);
		newsStoryDesc = (have_ParentAppControl) ? singleSymbol_Factory.createNew_DescTagName("newsStoryDesc", true) :
				singleSymbol_Factory.createNew_DescTagName("newsStoryDesc", 442, true, null);



		//  MultiPart Symbols _________________________________________________________________________

		//  `FIELD`.`NAMES`
		symbolStrings = new ArrayList<String>();
		symbolStrings.add("FIELD");
		symbolStrings.add("NAMES");

		FIELD$__$NAMES = (have_ParentAppControl) ? multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, 346, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols) :

				multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols);


		//  `FIELD`.`TYPES`
		symbolStrings = new ArrayList<String>();
		symbolStrings.add("FIELD");
		symbolStrings.add("TYPES");

		FIELD$__$TYPES = (have_ParentAppControl) ? multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, 347, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols) :

				multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols);


		//  `FIELD`.`DESC`
		symbolStrings = new ArrayList<String>();
		symbolStrings.add("FIELD");
		symbolStrings.add("DESC");

		FIELD$__$DESC = (have_ParentAppControl) ? multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, 348, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols) :

				multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols);


		//  `FIELD`.`DEFAULTS`
		symbolStrings = new ArrayList<String>();
		symbolStrings.add("FIELD");
		symbolStrings.add("DEFAULTS");

		FIELD$__$DEFAULTS = (have_ParentAppControl) ? multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, 349, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols) :

				multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols);


		//  `MATRIX`.`BASE`
		symbolStrings = new ArrayList<String>();
		symbolStrings.add("MATRIX");
		symbolStrings.add("BASE");

		MATRIX$__$BASE = (have_ParentAppControl) ? multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, 351, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols) :

				multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols);


		//  `MATRIX`.`STANDARD`
		symbolStrings = new ArrayList<String>();
		symbolStrings.add("MATRIX");
		symbolStrings.add("STANDARD");

		MATRIX$__$STANDARD = (have_ParentAppControl) ? multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, 352, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols) :

				multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols);


		//  `MATRIXPROG`.`PERSISTENCE`
		symbolStrings = new ArrayList<String>();
		symbolStrings.add("MATRIXPROG");
		symbolStrings.add("PERSISTENCE");

		MATRIXPROG$__$PERSISTENCE = (have_ParentAppControl) ? multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, 354, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols) :

				multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols);


		//  `MATRIXPROG`.`PERSISTENCE`.`SETTINGS`
		symbolStrings = new ArrayList<String>();
		symbolStrings.add("MATRIXPROG");
		symbolStrings.add("PERSISTENCE");
		symbolStrings.add("SETTINGS");

		MATRIXPROG$__$PERSISTENCE$__$SETTINGS = (have_ParentAppControl) ? multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, 355, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols) :

				multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols);


		//  `net`.`unconventionalthinking`
		symbolStrings = new ArrayList<String>();
		symbolStrings.add("net");
		symbolStrings.add("unconventionalthinking");

		net$__$unconventionalthinking = (have_ParentAppControl) ? multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, 357, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols) :

				multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols);


		//  `net`.`unconventionalthinking`.`matrix`
		symbolStrings = new ArrayList<String>();
		symbolStrings.add("net");
		symbolStrings.add("unconventionalthinking");
		symbolStrings.add("matrix");

		net$__$unconventionalthinking$__$matrix = (have_ParentAppControl) ? multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, 358, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols) :

				multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols);


		//  `net`.`unconventionalthinking`.`matrix`.`schema`
		symbolStrings = new ArrayList<String>();
		symbolStrings.add("net");
		symbolStrings.add("unconventionalthinking");
		symbolStrings.add("matrix");
		symbolStrings.add("schema");

		net$__$unconventionalthinking$__$matrix$__$schema = (have_ParentAppControl) ? multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, 359, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols) :

				multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols);


		//  `WEB`.`FORM`
		symbolStrings = new ArrayList<String>();
		symbolStrings.add("WEB");
		symbolStrings.add("FORM");

		WEB$__$FORM = (have_ParentAppControl) ? multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, 361, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols) :

				multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols);


		//  `com`.`williespetstore`
		symbolStrings = new ArrayList<String>();
		symbolStrings.add("com");
		symbolStrings.add("williespetstore");

		com$__$williespetstore = (have_ParentAppControl) ? multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, 363, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols) :

				multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols);


		//  `News`.`Schema`
		symbolStrings = new ArrayList<String>();
		symbolStrings.add("News");
		symbolStrings.add("Schema");

		News$__$Schema = (have_ParentAppControl) ? multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, 365, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols) :

				multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols);


		//  `NEWS`.`STORY`
		symbolStrings = new ArrayList<String>();
		symbolStrings.add("NEWS");
		symbolStrings.add("STORY");

		NEWS$__$STORY = (have_ParentAppControl) ? multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, 367, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols) :

				multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols);


		//  `net`.`unconventional`
		symbolStrings = new ArrayList<String>();
		symbolStrings.add("net");
		symbolStrings.add("unconventional");

		net$__$unconventional = (have_ParentAppControl) ? multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, 368, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols) :

				multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols);


		//  `net`.`unconventional`.`persistence`
		symbolStrings = new ArrayList<String>();
		symbolStrings.add("net");
		symbolStrings.add("unconventional");
		symbolStrings.add("persistence");

		net$__$unconventional$__$persistence = (have_ParentAppControl) ? multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, 369, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols) :

				multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols);


		//  `WilliesPetstore`.`Content`
		symbolStrings = new ArrayList<String>();
		symbolStrings.add("WilliesPetstore");
		symbolStrings.add("Content");

		WilliesPetstore$__$Content = (have_ParentAppControl) ? multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, 421, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols) :

				multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols);


		//  `com`.`williespetstore`.`app`
		symbolStrings = new ArrayList<String>();
		symbolStrings.add("com");
		symbolStrings.add("williespetstore");
		symbolStrings.add("app");

		com$__$williespetstore$__$app = (have_ParentAppControl) ? multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, 433, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols) :

				multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols);


		//  `org`.`apache`
		symbolStrings = new ArrayList<String>();
		symbolStrings.add("org");
		symbolStrings.add("apache");

		org$__$apache = (have_ParentAppControl) ? multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, 438, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols) :

				multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols);


		//  `org`.`apache`.`jsp`
		symbolStrings = new ArrayList<String>();
		symbolStrings.add("org");
		symbolStrings.add("apache");
		symbolStrings.add("jsp");

		org$__$apache$__$jsp = (have_ParentAppControl) ? multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, 439, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols) :

				multiPartSymbol_Factory.createNew_DescTagName(symbolStrings, creation_StartLevel, creation_Has_StaticVersion, have_Created_New_MultiPartSymbol, newlyCreatedSymbols);


		have_Intialized = true;
	}


}
