package com.williespetstore;

import com.williespetstore.News$__$Schema;
import com.williespetstore.WilliesPetstore$__$Content;
import com.williespetstore.app.AppSymbols_DescTag;
import com.williespetstore.app.AppSymbols_DescTagName;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import javax.servlet.ServletContext;
import net.unconventionalthinking.matrix.Matrix;
import net.unconventionalthinking.matrix.SchemaInfo_Schema;

/**
 *
 * @author Peter Joh
 */
public class Junk {
    public void junk() {
        ServletContext sc= null;
        URL configFile_Url = null;
        URL url = null;
    }
}
