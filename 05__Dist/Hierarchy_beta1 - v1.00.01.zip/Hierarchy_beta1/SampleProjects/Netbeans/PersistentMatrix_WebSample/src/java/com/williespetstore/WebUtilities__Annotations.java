/*  ~*~*~Matrix Meta-Compiled File~*~*~  */

package com.williespetstore;

import net.unconventionalthinking.exceptions.*;
import com.williespetstore.app.AppSymbols_MatrixName;
import net.unconventionalthinking.matrix.*;
import com.williespetstore.app.AppSymbols_DescTagName;
import com.williespetstore.app.AppSymbols_SchemaName;
import net.unconventionalthinking.lang.*;
import net.unconventionalthinking.matrix.symbols.*;
import net.unconventionalthinking.matrix.metacompiler.codegen.Exception_MetaCompilerError;
import com.williespetstore.app.AppSymbols;
import com.williespetstore.app.AppSymbols_Label;
import com.williespetstore.app.AppControl;
import com.williespetstore.app.AppSymbols_DescTag;




public interface WebUtilities__Annotations {



}
