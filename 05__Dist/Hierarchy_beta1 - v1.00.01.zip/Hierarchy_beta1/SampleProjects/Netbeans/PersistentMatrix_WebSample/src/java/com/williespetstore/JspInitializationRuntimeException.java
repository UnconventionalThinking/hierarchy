/*  ~*~*~Matrix Meta-Compiled File~*~*~  */

package com . williespetstore ;
public  class JspInitializationRuntimeException extends RuntimeException  implements JspInitializationRuntimeException__Annotations {
	public JspInitializationRuntimeException ( String errorMsg ) {
		super ( errorMsg ) ;
		
	}
	public JspInitializationRuntimeException ( String errorMsg , Throwable cause ) {
		super ( errorMsg , cause ) ;
		
	}
	




}
