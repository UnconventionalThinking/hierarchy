
Instructions to build and run any of these sample project
_________________________________________________________

To use the sample projects, your system is required to have:

   1. Java 1.6 or above installed on your system
   2. Ant 1.6 or above installed on your system and can run Ant from the command line.
   3. If you�d like to use the sample web projects, install Tomcat 6.0 on your system and Java 1.6.
   4. A current version of Netbeans (6.9 or higher) or Eclipse on your system
      * Currently, Hierarchy supports Netbeans better than Eclipse. It is recommended that you use Netbeans if possible (no disrespect to Eclipse developers, it just happened to be that certain features we�re easier to implement in Netbeans than Eclipse). 
   5. Hierarchy�s metacompiler works with PC / UNIX / Linux / Mac.


Let�s meta-compiling and run a sample project:


   1. After unzipping your Hierarchy download, using your file manager, go to the MatrixSample_Basic directory (or, any other of the sample project directories! These instructions should work the same for all to them). The sample projects are located in the Hierarchy/samples/Netbeans. 

   2. In the base directory of the sample project, find the file called: hierarchy.properties. Open this file in a text editor and set the first two properties to the correct directories on your local system:

		#  Set the path to the Hierarchy.jar directory.
		hierarchy.jar.dir=/Projects/Hierarchy/Samples/bin

		#  Set the path to the javac directory.
		javac.dir=/Java/jdk1.6.0_11/bin


   3. If you�re working with one of the sample web projects, you should setup tomcat server in your IDE:

      a. First, install the Apache Tomcat on your system (if you haven�t done so already).
      b. Next, in Netbeans, you need to add the server to your IDE (again, if you haven�t already done so). You do this in the Tools menu under Servers. 
      c. * You also need to let the ant build script, buildJSP.xml, know where your Tomcat installation is. Open buildJSP.xml in a text editor, and edit the following line to point to your tomcat base dir.

        <property name="tomcat.home" value="/Java/servers/tomcat-6.0.29"/>

   4. Open up the sample project in the Netbeans IDE. If necessary, fix the references to the jars used by the project. You can tell if you need to do this if your project icon shows an error sign. This should mean there are broken references to jars. If you need to fix these, open up the Properties for the project, and the Project Properties dialog box should pop up. Then, in Categories window-pane on the left side, select Libraries. In the libraries window-pane, if there are any broken references, remove them and add the corrected references back in. You need references to the following three jars:
   
      a. Hierarchy.jar - located in Hierarchy/bin
      b. commons-collections-3.2.1 - located in Hierarchy/bin/lib
      c. sablecc.jar - (actually, not needed for most projects)located in Hierarchy/bin/lib

   5. At this point, you can just use the "build" and "clean" menu items to metacompile and properly clean the project. The reason you can do this is because for each of the sample projects, behind the scenes, the Netbeans build script, "build.xml," has some custom ant code that calls the matrix build-script  ("buildMatrix.xml" or "buildJSP.xml"). This lets you build all the matrix-related parts of the project directly in Netbeans. 

   And, since you can build the matrix-related parts of the project directly in Netbeans, you can skip the next steps (steps 5 - 6) which show you how to build these matrix-related parts manually. They show you how to do this building of the matrix-related elements outside of Netbeans from the command line. If you�re not interested in learning how this is done, feel free to skip ahead to step 7. But, we highly recommended that you try steps 5 and 6! The reason is so you can get a more in depth understanding of how the metacompilation process works, which will be useful if you need to debug problems or create your own matrix project. 


   6. Now, let�s meta-compiling the code. If you look at the source code for the sample project, most of it is Hierarchy, meta-code files. You can tell they are meta-code files because they have one of the following extensions: .matrix, .schema, .mjava, or .mjsp. We need to meta-compile these into .java files. To do this, on the command line, cd to the sample project�s directory, and run the ant command: 
   
       ant -f buildMatrix.xml

    Or, for one of the web projects, run:
   
       ant -f buildJSP.xml

    This should metacompile the project. If you look again in the sample project�s source code, you should see new .java files added into the source. You can open this project up in your IDE to take a look at the generated files. 

    To open the project in Netbeans, select the menu item: Files > Open Project. And navigate to the sample project under Hierarchy/samples/Netbeans.

   7. Next, let�s compile the generated .java files. At this point, we�ll compile the Java files generated by the Hierarchy metacompiler into byte code. This is done pretty much the standard way. If you�re using Netbeans or Eclipse, open the project in the IDE and perform a "build".

   8. Let�s run the project. If you�re using Netbeans, to run the MatrixSample_Basic project, click on the "run project" button. Alternatively, go to the command line, cd to the directory, MatrixSample_Basic/dist, and run the command:

      java -jar "MatrixSample_Basic.jar"

   9. To clean the project:
      a. In Netbeans - by selecting "clean" from the project menu, this will both clean the .java files generated by the meta-compiler, and the .class files generated by the java compiler. Behind the scenes, the project�s Netbeans "build.xml" ant script calls the Hierarchy "buildMatrix.xml" ant script to clean out the generated Java files (see the next step to see exactly what in this script is called).

      b. OR, to clean the matrix-related parts of the project from the command line  - In a terminal window, at the project�s directory, type:

         ant -f buildMatrix.xml clean

       Or, for a web project:  

         ant -f buildJSP.xml clean

   10. If you run into any problems, please refer to the FAQ document! It contains answers to common problems.


   11. Also, if you want to try some the examples in this Developer Guide for yourself, you may want to work with a copy one of the sample projects. 
      a. Copy one of the sample projects into it�s own directory.
      b. Modify the properties in hierarchy.properties to point to the correct paths in your system
      c. If you�re copying one of the web projects, modify the buildJSP.xml file to point tomcat.home to the correct file path of your tomcat installation.
      d. Try metacompiling and then compiling the project to see if it works.
      e. Now, you can try out any modifications you�d like.

... And, just as a reminder, you can metacompile and properly clean the sample projects directly from the Netbeans IDE (meaning, you don�t have to do steps 5-6 in the previous instructions). 

Enjoy!

