/*  ~*~*~Matrix Meta-Compiled File~*~*~  */

package com.williespetstore;


import net.unconventionalthinking.exceptions.*;
import com.williespetstore.app.AppSymbols_DescTagName;
import net.unconventionalthinking.matrix.*;
import java.util.Arrays;
import net.unconventionalthinking.lang.*;
import net.unconventionalthinking.matrix.symbols.*;
import java . text . DateFormat ;

import java . util . Date ;

import com.williespetstore.app.AppSymbols;
import com.williespetstore.app.AppControl;
import com.williespetstore.app.AppSymbols_DescTag;
import com.williespetstore.app.AppSymbols_MatrixName;
import com.williespetstore.app.AppSymbols_SchemaName;
import net.unconventionalthinking.matrix.metacompiler.codegen.Exception_MetaCompilerError;
import com.williespetstore.app.AppSymbols_Label;
import java.util.LinkedList;




public class WilliesPetstore$__$Content implements MatrixContainer {

	public static Matrix matrix;


	public static Matrix construct(AppControl_Base appControl, ExecutionInfo executeInfo)
		throws Exception_MatrixRuntime_Checked {

		LinkedList<MatrixSet<SchemaInfo_Schema>> schemaSet_ScopeStack = new LinkedList<MatrixSet<SchemaInfo_Schema>>();

		//  Creating a Matrix with name, `WilliesPetstore`.`Content`__________________________________________________
		try {
			schemaSet_ScopeStack.add(new MatrixSet<SchemaInfo_Schema>().add(
				appControl.schemaControl.schemaFactory.get_BaseSchema(executeInfo),
				appControl.schemaControl.schemaForSchema
			));
		} catch (Exception e) {
			throw new Exception_MatrixRuntime_Checked("while trying to create a new Matrix Or Schema descriptor with the name, `WilliesPetstore`.`Content`," + 
				" tried to add the Base Schema to the scope stack, but had an error creating it (see inner exception).", e);
		}

		MatrixSet<SchemaInfo_Schema> descriptor15$_X_$MATRIX$_X_$__UsesSchemaSet;
		Descriptor descriptor15$_X_$MATRIX;

		try {
			descriptor15$_X_$MATRIX$_X_$__UsesSchemaSet = new MatrixSet<SchemaInfo_Schema>().add(appControl.schemaControl.schemaIndex_Find(AppSymbols_SchemaName.com$__$williespetstore$_CC_$News$__$Schema), appControl.schemaControl.schemaIndex_Find(AppSymbols_SchemaName.net$__$unconventional$__$persistence$_CC_$MATRIXPROG$__$PERSISTENCE));
			descriptor15$_X_$MATRIX = (Descriptor)appControl.matrixControl.matrixFactory.createNew_Matrix(executeInfo, AppSymbols_Label.WilliesPetstore$__$Content, AppSymbols_DescTagName.com$__$williespetstore, true, descriptor15$_X_$MATRIX$_X_$__UsesSchemaSet, null, true, 10);
			schemaSet_ScopeStack.add(descriptor15$_X_$MATRIX$_X_$__UsesSchemaSet);

		} catch(Exception e) {
			throw new Exception_MatrixRuntime_Checked("Tried to create a new descriptor with the name, MATRIX::MATRIX, and with label, `WilliesPetstore`.`Content`, but had an error", e);
		}


		//  Creating a Descriptor with descriptor tag, MATRIXPROG.PERSISTENCE.SETTINGS::MATRIXPROG.PERSISTENCE.SETTINGS, and label, null__________________________________________________
		MatrixSet<SchemaInfo_Schema> descriptor16$_X_$MATRIXPROG_PERSISTENCE_SETTINGS$_X_$__UsesSchemaSet;
		Descriptor descriptor16$_X_$MATRIXPROG_PERSISTENCE_SETTINGS;

		try {
			descriptor16$_X_$MATRIXPROG_PERSISTENCE_SETTINGS$_X_$__UsesSchemaSet = new MatrixSet<SchemaInfo_Schema>();
			descriptor16$_X_$MATRIXPROG_PERSISTENCE_SETTINGS = (Descriptor)appControl.matrixControl.matrixFactory.createNew_Descriptor(executeInfo, appControl.schemaControl.schemaIndex_Find(AppSymbols_SchemaName.net$__$unconventional$__$persistence$_CC_$MATRIXPROG$__$PERSISTENCE).getChild_SchemaInfoDescriptor(executeInfo, AppSymbols_DescTag.net$__$unconventional$__$persistence$_CC_$MATRIXPROG$__$PERSISTENCE$_CC_$MATRIXPROG$__$PERSISTENCE$__$SETTINGS), null, descriptor16$_X_$MATRIXPROG_PERSISTENCE_SETTINGS$_X_$__UsesSchemaSet, descriptor15$_X_$MATRIX, 11);
			com.williespetstore.app.FieldSetTuple__net$__$unconventional$__$persistence$_CC_$MATRIXPROG$__$PERSISTENCE$_S_$MATRIXPROG$__$PERSISTENCE$__$SETTINGS descriptor16$_X_$MATRIXPROG_PERSISTENCE_SETTINGS$_X_$__FieldSet = (com.williespetstore.app.FieldSetTuple__net$__$unconventional$__$persistence$_CC_$MATRIXPROG$__$PERSISTENCE$_S_$MATRIXPROG$__$PERSISTENCE$__$SETTINGS)descriptor16$_X_$MATRIXPROG_PERSISTENCE_SETTINGS.get_FieldSet_Tuple(executeInfo);
			descriptor16$_X_$MATRIXPROG_PERSISTENCE_SETTINGS$_X_$__FieldSet.set_IsPersistentMatrix(executeInfo, AppSymbols.IsPersistent );
			schemaSet_ScopeStack.add(descriptor16$_X_$MATRIXPROG_PERSISTENCE_SETTINGS$_X_$__UsesSchemaSet);
			descriptor15$_X_$MATRIX.add_ChildDescriptor(executeInfo, descriptor16$_X_$MATRIXPROG_PERSISTENCE_SETTINGS);

		} catch(Exception e) {
			throw new Exception_MatrixRuntime_Checked("Tried to create a new descriptor with the name, MATRIXPROG.PERSISTENCE.SETTINGS::MATRIXPROG.PERSISTENCE.SETTINGS, and with an empty label, but had an error", e);
		}


		//  Creating a Descriptor with descriptor tag, NEWS::NEWS, and label, null__________________________________________________
		MatrixSet<SchemaInfo_Schema> descriptor17$_X_$NEWS$_X_$__UsesSchemaSet;
		Descriptor descriptor17$_X_$NEWS;

		try {
			descriptor17$_X_$NEWS$_X_$__UsesSchemaSet = new MatrixSet<SchemaInfo_Schema>();
			descriptor17$_X_$NEWS = (Descriptor)appControl.matrixControl.matrixFactory.createNew_Descriptor(executeInfo, appControl.schemaControl.schemaIndex_Find(AppSymbols_SchemaName.com$__$williespetstore$_CC_$News$__$Schema).getChild_SchemaInfoDescriptor(executeInfo, AppSymbols_DescTag.com$__$williespetstore$_CC_$News$__$Schema$_CC_$NEWS), null, descriptor17$_X_$NEWS$_X_$__UsesSchemaSet, descriptor15$_X_$MATRIX, 12);
			com.williespetstore.app.FieldSetTuple__com$__$williespetstore$_CC_$News$__$Schema$_S_$NEWS descriptor17$_X_$NEWS$_X_$__FieldSet = (com.williespetstore.app.FieldSetTuple__com$__$williespetstore$_CC_$News$__$Schema$_S_$NEWS)descriptor17$_X_$NEWS.get_FieldSet_Tuple(executeInfo);
			descriptor17$_X_$NEWS$_X_$__FieldSet.set_NewsSectionName(executeInfo, "HomePage News Blurbs" );
			schemaSet_ScopeStack.add(descriptor17$_X_$NEWS$_X_$__UsesSchemaSet);
			descriptor15$_X_$MATRIX.add_ChildDescriptor(executeInfo, descriptor17$_X_$NEWS);

		} catch(Exception e) {
			throw new Exception_MatrixRuntime_Checked("Tried to create a new descriptor with the name, NEWS::NEWS, and with an empty label, but had an error", e);
		}


		//  Creating a Descriptor with descriptor tag, NEWS.STORY::NEWS.STORY, and label, Fanciful Dog Food__________________________________________________
		MatrixSet<SchemaInfo_Schema> descriptor18$_X_$NEWS_STORY$_X_$__UsesSchemaSet;
		Descriptor descriptor18$_X_$NEWS_STORY;

		try {
			descriptor18$_X_$NEWS_STORY$_X_$__UsesSchemaSet = new MatrixSet<SchemaInfo_Schema>();
			descriptor18$_X_$NEWS_STORY = (Descriptor)appControl.matrixControl.matrixFactory.createNew_Descriptor(executeInfo, appControl.schemaControl.schemaIndex_Find(AppSymbols_SchemaName.com$__$williespetstore$_CC_$News$__$Schema).getChild_SchemaInfoDescriptor(executeInfo, AppSymbols_DescTag.com$__$williespetstore$_CC_$News$__$Schema$_CC_$NEWS).getChild_SchemaInfoDescriptor(executeInfo, AppSymbols_DescTag.com$__$williespetstore$_CC_$News$__$Schema$_CC_$NEWS$__$STORY), appControl.symbolControl.multiPartSymbol_Factory.createNew_Label(Arrays.asList("Fanciful Dog Food"), 0, true), descriptor18$_X_$NEWS_STORY$_X_$__UsesSchemaSet, descriptor17$_X_$NEWS, 13);
			com.williespetstore.app.FieldSetTuple__com$__$williespetstore$_CC_$News$__$Schema$_S_$NEWS$_S_$NEWS$__$STORY descriptor18$_X_$NEWS_STORY$_X_$__FieldSet = (com.williespetstore.app.FieldSetTuple__com$__$williespetstore$_CC_$News$__$Schema$_S_$NEWS$_S_$NEWS$__$STORY)descriptor18$_X_$NEWS_STORY.get_FieldSet_Tuple(executeInfo);
			descriptor18$_X_$NEWS_STORY$_X_$__FieldSet.set_StoryDate(executeInfo, "March 10, 2010" );
			descriptor18$_X_$NEWS_STORY$_X_$__FieldSet.set_Title(executeInfo, "20% off Fanciful Dog Spread" );
			descriptor18$_X_$NEWS_STORY$_X_$__FieldSet.set_StoryContent(executeInfo, "For one day only, come and pick up your tub of Fanciful Dog Spread! A truly refined and tasteful topping your dog will dream about." );
			schemaSet_ScopeStack.add(descriptor18$_X_$NEWS_STORY$_X_$__UsesSchemaSet);
			descriptor17$_X_$NEWS.add_ChildDescriptor(executeInfo, descriptor18$_X_$NEWS_STORY);

		} catch(Exception e) {
			throw new Exception_MatrixRuntime_Checked("Tried to create a new descriptor with the name, NEWS.STORY::NEWS.STORY, and with label, Fanciful Dog Food, but had an error", e);
		}


		//  Creating a Descriptor with descriptor tag, NEWS.STORY::NEWS.STORY, and label, Adopt a Pet__________________________________________________
		MatrixSet<SchemaInfo_Schema> descriptor19$_X_$NEWS_STORY$_X_$__UsesSchemaSet;
		Descriptor descriptor19$_X_$NEWS_STORY;

		try {
			descriptor19$_X_$NEWS_STORY$_X_$__UsesSchemaSet = new MatrixSet<SchemaInfo_Schema>();
			descriptor19$_X_$NEWS_STORY = (Descriptor)appControl.matrixControl.matrixFactory.createNew_Descriptor(executeInfo, appControl.schemaControl.schemaIndex_Find(AppSymbols_SchemaName.com$__$williespetstore$_CC_$News$__$Schema).getChild_SchemaInfoDescriptor(executeInfo, AppSymbols_DescTag.com$__$williespetstore$_CC_$News$__$Schema$_CC_$NEWS).getChild_SchemaInfoDescriptor(executeInfo, AppSymbols_DescTag.com$__$williespetstore$_CC_$News$__$Schema$_CC_$NEWS$__$STORY), appControl.symbolControl.multiPartSymbol_Factory.createNew_Label(Arrays.asList("Adopt a Pet"), 0, true), descriptor19$_X_$NEWS_STORY$_X_$__UsesSchemaSet, descriptor17$_X_$NEWS, 14);
			com.williespetstore.app.FieldSetTuple__com$__$williespetstore$_CC_$News$__$Schema$_S_$NEWS$_S_$NEWS$__$STORY descriptor19$_X_$NEWS_STORY$_X_$__FieldSet = (com.williespetstore.app.FieldSetTuple__com$__$williespetstore$_CC_$News$__$Schema$_S_$NEWS$_S_$NEWS$__$STORY)descriptor19$_X_$NEWS_STORY.get_FieldSet_Tuple(executeInfo);
			descriptor19$_X_$NEWS_STORY$_X_$__FieldSet.set_StoryDate(executeInfo, "March 17, 2010" );
			descriptor19$_X_$NEWS_STORY$_X_$__FieldSet.set_Title(executeInfo, "Adopt a Pet" );
			descriptor19$_X_$NEWS_STORY$_X_$__FieldSet.set_StoryContent(executeInfo, "Your chance to adopt a lonely doggie is right around the corner. Come by Willie's Pets on Sunday to find the personality that's a perfect match for you!" );
			schemaSet_ScopeStack.add(descriptor19$_X_$NEWS_STORY$_X_$__UsesSchemaSet);
			descriptor17$_X_$NEWS.add_ChildDescriptor(executeInfo, descriptor19$_X_$NEWS_STORY);

		} catch(Exception e) {
			throw new Exception_MatrixRuntime_Checked("Tried to create a new descriptor with the name, NEWS.STORY::NEWS.STORY, and with label, Adopt a Pet, but had an error", e);
		}


		//  Creating a Descriptor with descriptor tag, NEWS.STORY::NEWS.STORY, and label, xxcx__________________________________________________
		MatrixSet<SchemaInfo_Schema> descriptor20$_X_$NEWS_STORY$_X_$__UsesSchemaSet;
		Descriptor descriptor20$_X_$NEWS_STORY;

		try {
			descriptor20$_X_$NEWS_STORY$_X_$__UsesSchemaSet = new MatrixSet<SchemaInfo_Schema>();
			descriptor20$_X_$NEWS_STORY = (Descriptor)appControl.matrixControl.matrixFactory.createNew_Descriptor(executeInfo, appControl.schemaControl.schemaIndex_Find(AppSymbols_SchemaName.com$__$williespetstore$_CC_$News$__$Schema).getChild_SchemaInfoDescriptor(executeInfo, AppSymbols_DescTag.com$__$williespetstore$_CC_$News$__$Schema$_CC_$NEWS).getChild_SchemaInfoDescriptor(executeInfo, AppSymbols_DescTag.com$__$williespetstore$_CC_$News$__$Schema$_CC_$NEWS$__$STORY), appControl.symbolControl.multiPartSymbol_Factory.createNew_Label(Arrays.asList("xxcx"), 0, true), descriptor20$_X_$NEWS_STORY$_X_$__UsesSchemaSet, descriptor17$_X_$NEWS, 15);
			com.williespetstore.app.FieldSetTuple__com$__$williespetstore$_CC_$News$__$Schema$_S_$NEWS$_S_$NEWS$__$STORY descriptor20$_X_$NEWS_STORY$_X_$__FieldSet = (com.williespetstore.app.FieldSetTuple__com$__$williespetstore$_CC_$News$__$Schema$_S_$NEWS$_S_$NEWS$__$STORY)descriptor20$_X_$NEWS_STORY.get_FieldSet_Tuple(executeInfo);
			descriptor20$_X_$NEWS_STORY$_X_$__FieldSet.set_StoryDate(executeInfo, "June, 17 2011" );
			descriptor20$_X_$NEWS_STORY$_X_$__FieldSet.set_Title(executeInfo, "xxcx" );
			descriptor20$_X_$NEWS_STORY$_X_$__FieldSet.set_StoryContent(executeInfo, "sdfsdfsf" );
			schemaSet_ScopeStack.add(descriptor20$_X_$NEWS_STORY$_X_$__UsesSchemaSet);
			descriptor17$_X_$NEWS.add_ChildDescriptor(executeInfo, descriptor20$_X_$NEWS_STORY);

		} catch(Exception e) {
			throw new Exception_MatrixRuntime_Checked("Tried to create a new descriptor with the name, NEWS.STORY::NEWS.STORY, and with label, xxcx, but had an error", e);
		}

		matrix = (Matrix)descriptor15$_X_$MATRIX;

		return (Matrix)descriptor15$_X_$MATRIX;
	}




	public Class<?> get_AppControl_Class() throws ClassNotFoundException {
		return com.williespetstore.app.AppControl.class;
	}
	public AppControl_Base initialize_AppControl() { return initialize_AppControl(null, false); }
	public AppControl_Base initialize_AppControl(boolean running_AppControl_forMetacompilation) { return initialize_AppControl(null, running_AppControl_forMetacompilation); }
	public AppControl_Base initialize_AppControl(AppControl_Base existing_AppControl) { return initialize_AppControl(existing_AppControl, false); }
	public AppControl_Base initialize_AppControl(AppControl_Base existing_AppControl, boolean running_AppControl_forMetacompilation) {
		if (existing_AppControl != null)
			return com.williespetstore.app.AppControl.initializeApp(existing_AppControl, running_AppControl_forMetacompilation);
		else
			return com.williespetstore.app.AppControl.initializeApp(running_AppControl_forMetacompilation);
	}

	public AppControl_Base get_AppControl() {
		return com.williespetstore.app.AppControl.appControl;
	}

}
