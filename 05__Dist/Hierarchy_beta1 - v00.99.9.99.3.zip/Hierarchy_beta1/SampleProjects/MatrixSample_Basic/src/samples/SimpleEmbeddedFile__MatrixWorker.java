package samples;

import net.unconventionalthinking.exceptions.*;
import net . unconventionalthinking . matrix . * ;

import samples.matrix.app.AppSymbols_MatrixName;
import net.unconventionalthinking.matrix.*;
import samples.matrix.app.AppControl;
import net.unconventionalthinking.lang.*;
import samples.matrix.app.AppSymbols;
import net.unconventionalthinking.matrix.symbols.*;
import samples.matrix.app.AppSymbols_SchemaName;
import net . unconventionalthinking . lang . * ;

import samples.matrix.app.AppSymbols_Label;
import samples . matrix . app . * ;

import samples.matrix.app.AppSymbols_DescTag;
import net.unconventionalthinking.matrix.metacompiler.codegen.Exception_MetaCompilerError;
import net . unconventionalthinking . matrix . symbols . * ;

import samples.matrix.app.AppSymbols_DescTagName;



public class SimpleEmbeddedFile__MatrixWorker {



	public static Descriptor accessMatrix_Simple$__$Matrix__15(ExecutionInfo executeInfo, SimpleEmbeddedFile__Annotations callerObj) {

		//  Static Descriptor Access by Static Label, `Davey`.`Jones`.
		Descriptor Descriptor__24__STATIC__LBL_Davey$__$Jones = null;

		if (DescriptorUtilities.validDescriptors(executeInfo, samples.Simple$__$Matrix.matrix)) {
			try{
				Descriptor__24__STATIC__LBL_Davey$__$Jones = samples.Simple$__$Matrix.matrix.get_ChildDescriptor(executeInfo, AppSymbols_Label.Davey$__$Jones);
			} catch (Exception e) {
				executeInfo.setErrorException(e);
			}

		} else { // end of if (validDescriptors())
			executeInfo.addErrorInfo(ExecutionInfo.ErrorType.AccessedDescriptorThatWasNotFound);
		}

		// Error handling code
		if (executeInfo.get_HadError()) {
			AnnotationParameters_AccessReturnType_OutParam accessReturnType_OutParam = new AnnotationParameters_AccessReturnType_OutParam();
			Object annotateRetVal = callerObj.annotationHandler_1(executeInfo, false, null, 0, 0, AnnotationParameters.AccessType.Descriptor, accessReturnType_OutParam, samples.Simple$__$Matrix.matrix, samples.Simple$__$Matrix.matrix, null, true, executeInfo.getErrorException(), new Pair<Object, Object>(AppSymbols_Label.Davey$__$Jones, null));

			if (executeInfo.get_HadError() && executeInfo.containsError(ExecutionInfo.ErrorType.AbortAccess)) 
				throw new ExceptRuntime_MatrixAccessError("Was trying the first access of the Matrix named samples.Simple$__$Matrix.matrix but had an error. The annotation handler tried to process this error but was not able to.");

			if (accessReturnType_OutParam != null && accessReturnType_OutParam.returnType == AnnotationParameters.AccessReturnType.accessorValue)
				Descriptor__24__STATIC__LBL_Davey$__$Jones = (Descriptor)annotateRetVal;
			else // accessReturnType_OutParam.returnType == AnnotationParameters.AccessReturnType.accessValue)
				return (Descriptor)annotateRetVal;
		}



		return Descriptor__24__STATIC__LBL_Davey$__$Jones;

	}





	//  Continued Access
	public static String accessMatrix___16(ExecutionInfo executeInfo, Descriptor descriptor, SimpleEmbeddedFile__Annotations callerObj) {


		//  Static Field Access by Static Descriptor Tag Name, FirstName.
		if (DescriptorUtilities.validDescriptors(executeInfo, descriptor)) {
			try{
				if (descriptor.has_FieldSet()) {
					return ((samples.matrix.app.FieldSetTuple__samples$_CC_$Simple$__$Schema$_S_$PERSON)descriptor.get_FieldSet()).get_FirstName(executeInfo);
				} else {
					executeInfo.addErrorInfo(ExecutionInfo.ErrorType.AccessedFieldButNoFieldSetExists);
				}

			} catch (Exception e) {
				executeInfo.setErrorException(e);
			}

		} else { // end of if (validDescriptors())
			executeInfo.addErrorInfo(ExecutionInfo.ErrorType.AccessedDescriptorThatWasNotFound);
		}

		// Error handling code
		AnnotationParameters_AccessReturnType_OutParam accessReturnType_OutParam = new AnnotationParameters_AccessReturnType_OutParam();
		Object annotateRetVal = callerObj.annotationHandler_1(executeInfo, false, null, 0, 0, AnnotationParameters.AccessType.Field, accessReturnType_OutParam, descriptor, descriptor, null, true, executeInfo.getErrorException(), new Pair<Object, Object>(AppSymbols_DescTagName.FirstName, null));

		if (executeInfo.get_HadError() && executeInfo.containsError(ExecutionInfo.ErrorType.AbortAccess)) 
			throw new ExceptRuntime_MatrixAccessError("Was trying the first access of the Matrix named descriptor but had an error. The annotation handler tried to process this error but was not able to.");

		return (String)annotateRetVal;

	}





	//  Continued Access
	public static String accessMatrix___17(ExecutionInfo executeInfo, Descriptor descriptor, SimpleEmbeddedFile__Annotations callerObj) {


		//  Static Field Access by Static Descriptor Tag Name, LastName.
		if (DescriptorUtilities.validDescriptors(executeInfo, descriptor)) {
			try{
				if (descriptor.has_FieldSet()) {
					return ((samples.matrix.app.FieldSetTuple__samples$_CC_$Simple$__$Schema$_S_$PERSON)descriptor.get_FieldSet()).get_LastName(executeInfo);
				} else {
					executeInfo.addErrorInfo(ExecutionInfo.ErrorType.AccessedFieldButNoFieldSetExists);
				}

			} catch (Exception e) {
				executeInfo.setErrorException(e);
			}

		} else { // end of if (validDescriptors())
			executeInfo.addErrorInfo(ExecutionInfo.ErrorType.AccessedDescriptorThatWasNotFound);
		}

		// Error handling code
		AnnotationParameters_AccessReturnType_OutParam accessReturnType_OutParam = new AnnotationParameters_AccessReturnType_OutParam();
		Object annotateRetVal = callerObj.annotationHandler_1(executeInfo, false, null, 0, 0, AnnotationParameters.AccessType.Field, accessReturnType_OutParam, descriptor, descriptor, null, true, executeInfo.getErrorException(), new Pair<Object, Object>(AppSymbols_DescTagName.LastName, null));

		if (executeInfo.get_HadError() && executeInfo.containsError(ExecutionInfo.ErrorType.AbortAccess)) 
			throw new ExceptRuntime_MatrixAccessError("Was trying the first access of the Matrix named descriptor but had an error. The annotation handler tried to process this error but was not able to.");

		return (String)annotateRetVal;

	}





	//  Continued Access
	public static int accessMatrix___18(ExecutionInfo executeInfo, Descriptor descriptor, SimpleEmbeddedFile__Annotations callerObj) {


		//  Static Field Access by Static Descriptor Tag Name, Age.
		if (DescriptorUtilities.validDescriptors(executeInfo, descriptor)) {
			try{
				if (descriptor.has_FieldSet()) {
					return ((samples.matrix.app.FieldSetTuple__samples$_CC_$Simple$__$Schema$_S_$PERSON)descriptor.get_FieldSet()).get_Age(executeInfo);
				} else {
					executeInfo.addErrorInfo(ExecutionInfo.ErrorType.AccessedFieldButNoFieldSetExists);
				}

			} catch (Exception e) {
				executeInfo.setErrorException(e);
			}

		} else { // end of if (validDescriptors())
			executeInfo.addErrorInfo(ExecutionInfo.ErrorType.AccessedDescriptorThatWasNotFound);
		}

		// Error handling code
		AnnotationParameters_AccessReturnType_OutParam accessReturnType_OutParam = new AnnotationParameters_AccessReturnType_OutParam();
		Object annotateRetVal = callerObj.annotationHandler_1(executeInfo, false, null, 0, 0, AnnotationParameters.AccessType.Field, accessReturnType_OutParam, descriptor, descriptor, null, true, executeInfo.getErrorException(), new Pair<Object, Object>(AppSymbols_DescTagName.Age, null));

		if (executeInfo.get_HadError() && executeInfo.containsError(ExecutionInfo.ErrorType.AbortAccess)) 
			throw new ExceptRuntime_MatrixAccessError("Was trying the first access of the Matrix named descriptor but had an error. The annotation handler tried to process this error but was not able to.");

		return ((Integer)annotateRetVal).intValue();

	}





	public static MatrixSet<Descriptor> accessMatrix_Simple$__$Matrix__19(ExecutionInfo executeInfo, SimpleEmbeddedFile__Annotations callerObj, DescriptorTagName accessParam_0__value1) {


		//  Multi Access with access expression: AppSymbols_DescTagName.PERSON.
		MatrixSet<Descriptor> DescriptorSet__28__MULTI_ACCESS = null;
		if (DescriptorUtilities.validDescriptors(executeInfo, samples.Simple$__$Matrix.matrix)) {
			try{
				DescriptorSet__28__MULTI_ACCESS = samples.Simple$__$Matrix.matrix.get_ChildDescriptors(executeInfo,accessParam_0__value1);
			} catch (Exception e) {
				executeInfo.setErrorException(e);
			}

		} else { // end of if (validDescriptors())
			executeInfo.addErrorInfo(ExecutionInfo.ErrorType.AccessedDescriptorThatWasNotFound);
		}

		// Error handling code
		if (executeInfo.get_HadError()) {
			AnnotationParameters_AccessReturnType_OutParam accessReturnType_OutParam = new AnnotationParameters_AccessReturnType_OutParam();
			Object annotateRetVal = callerObj.annotationHandler_1(executeInfo, false, null, 0, 0, AnnotationParameters.AccessType.DescriptorSet, accessReturnType_OutParam, samples.Simple$__$Matrix.matrix, samples.Simple$__$Matrix.matrix, null, true, executeInfo.getErrorException(), new Pair<Object, Object>(accessParam_0__value1, null));

			if (executeInfo.get_HadError() && executeInfo.containsError(ExecutionInfo.ErrorType.AbortAccess)) 
				throw new ExceptRuntime_MatrixAccessError("Was trying the first access of the Matrix named samples.Simple$__$Matrix.matrix but had an error. The annotation handler tried to process this error but was not able to.");

			if (accessReturnType_OutParam != null && accessReturnType_OutParam.returnType == AnnotationParameters.AccessReturnType.accessorValue)
				DescriptorSet__28__MULTI_ACCESS = (MatrixSet<Descriptor>)annotateRetVal;
			else // accessReturnType_OutParam.returnType == AnnotationParameters.AccessReturnType.accessValue)
				return (MatrixSet<Descriptor>)annotateRetVal;
		}



		return DescriptorSet__28__MULTI_ACCESS;

	}





	//  Continued Access
	public static String accessMatrix___20(ExecutionInfo executeInfo, Descriptor descriptor, SimpleEmbeddedFile__Annotations callerObj) {


		//  Static Field Access by Static Descriptor Tag Name, FirstName.
		if (DescriptorUtilities.validDescriptors(executeInfo, descriptor)) {
			try{
				if (descriptor.has_FieldSet()) {
					return ((samples.matrix.app.FieldSetTuple__samples$_CC_$Simple$__$Schema$_S_$PERSON)descriptor.get_FieldSet()).get_FirstName(executeInfo);
				} else {
					executeInfo.addErrorInfo(ExecutionInfo.ErrorType.AccessedFieldButNoFieldSetExists);
				}

			} catch (Exception e) {
				executeInfo.setErrorException(e);
			}

		} else { // end of if (validDescriptors())
			executeInfo.addErrorInfo(ExecutionInfo.ErrorType.AccessedDescriptorThatWasNotFound);
		}

		// Error handling code
		AnnotationParameters_AccessReturnType_OutParam accessReturnType_OutParam = new AnnotationParameters_AccessReturnType_OutParam();
		Object annotateRetVal = callerObj.annotationHandler_1(executeInfo, false, null, 0, 0, AnnotationParameters.AccessType.Field, accessReturnType_OutParam, descriptor, descriptor, null, true, executeInfo.getErrorException(), new Pair<Object, Object>(AppSymbols_DescTagName.FirstName, null));

		if (executeInfo.get_HadError() && executeInfo.containsError(ExecutionInfo.ErrorType.AbortAccess)) 
			throw new ExceptRuntime_MatrixAccessError("Was trying the first access of the Matrix named descriptor but had an error. The annotation handler tried to process this error but was not able to.");

		return (String)annotateRetVal;

	}





	//  Continued Access
	public static String accessMatrix___21(ExecutionInfo executeInfo, Descriptor descriptor, SimpleEmbeddedFile__Annotations callerObj) {


		//  Static Field Access by Static Descriptor Tag Name, LastName.
		if (DescriptorUtilities.validDescriptors(executeInfo, descriptor)) {
			try{
				if (descriptor.has_FieldSet()) {
					return ((samples.matrix.app.FieldSetTuple__samples$_CC_$Simple$__$Schema$_S_$PERSON)descriptor.get_FieldSet()).get_LastName(executeInfo);
				} else {
					executeInfo.addErrorInfo(ExecutionInfo.ErrorType.AccessedFieldButNoFieldSetExists);
				}

			} catch (Exception e) {
				executeInfo.setErrorException(e);
			}

		} else { // end of if (validDescriptors())
			executeInfo.addErrorInfo(ExecutionInfo.ErrorType.AccessedDescriptorThatWasNotFound);
		}

		// Error handling code
		AnnotationParameters_AccessReturnType_OutParam accessReturnType_OutParam = new AnnotationParameters_AccessReturnType_OutParam();
		Object annotateRetVal = callerObj.annotationHandler_1(executeInfo, false, null, 0, 0, AnnotationParameters.AccessType.Field, accessReturnType_OutParam, descriptor, descriptor, null, true, executeInfo.getErrorException(), new Pair<Object, Object>(AppSymbols_DescTagName.LastName, null));

		if (executeInfo.get_HadError() && executeInfo.containsError(ExecutionInfo.ErrorType.AbortAccess)) 
			throw new ExceptRuntime_MatrixAccessError("Was trying the first access of the Matrix named descriptor but had an error. The annotation handler tried to process this error but was not able to.");

		return (String)annotateRetVal;

	}





	//  Continued Access
	public static int accessMatrix___22(ExecutionInfo executeInfo, Descriptor descriptor, SimpleEmbeddedFile__Annotations callerObj) {


		//  Static Field Access by Static Descriptor Tag Name, Age.
		if (DescriptorUtilities.validDescriptors(executeInfo, descriptor)) {
			try{
				if (descriptor.has_FieldSet()) {
					return ((samples.matrix.app.FieldSetTuple__samples$_CC_$Simple$__$Schema$_S_$PERSON)descriptor.get_FieldSet()).get_Age(executeInfo);
				} else {
					executeInfo.addErrorInfo(ExecutionInfo.ErrorType.AccessedFieldButNoFieldSetExists);
				}

			} catch (Exception e) {
				executeInfo.setErrorException(e);
			}

		} else { // end of if (validDescriptors())
			executeInfo.addErrorInfo(ExecutionInfo.ErrorType.AccessedDescriptorThatWasNotFound);
		}

		// Error handling code
		AnnotationParameters_AccessReturnType_OutParam accessReturnType_OutParam = new AnnotationParameters_AccessReturnType_OutParam();
		Object annotateRetVal = callerObj.annotationHandler_1(executeInfo, false, null, 0, 0, AnnotationParameters.AccessType.Field, accessReturnType_OutParam, descriptor, descriptor, null, true, executeInfo.getErrorException(), new Pair<Object, Object>(AppSymbols_DescTagName.Age, null));

		if (executeInfo.get_HadError() && executeInfo.containsError(ExecutionInfo.ErrorType.AbortAccess)) 
			throw new ExceptRuntime_MatrixAccessError("Was trying the first access of the Matrix named descriptor but had an error. The annotation handler tried to process this error but was not able to.");

		return ((Integer)annotateRetVal).intValue();

	}





	public static Descriptor accessMatrix_Simple$__$Matrix__23(ExecutionInfo executeInfo, SimpleEmbeddedFile__Annotations callerObj) {

		//  Static Descriptor Access by Static Label, `Jill`.`Daniels`.
		Descriptor Descriptor__32__STATIC__LBL_Jill$__$Daniels = null;

		if (DescriptorUtilities.validDescriptors(executeInfo, samples.Simple$__$Matrix.matrix)) {
			try{
				Descriptor__32__STATIC__LBL_Jill$__$Daniels = samples.Simple$__$Matrix.matrix.get_ChildDescriptor(executeInfo, AppSymbols_Label.Jill$__$Daniels);
			} catch (Exception e) {
				executeInfo.setErrorException(e);
			}

		} else { // end of if (validDescriptors())
			executeInfo.addErrorInfo(ExecutionInfo.ErrorType.AccessedDescriptorThatWasNotFound);
		}

		// Error handling code
		if (executeInfo.get_HadError()) {
			AnnotationParameters_AccessReturnType_OutParam accessReturnType_OutParam = new AnnotationParameters_AccessReturnType_OutParam();
			Object annotateRetVal = callerObj.annotationHandler_1(executeInfo, false, null, 0, 0, AnnotationParameters.AccessType.Descriptor, accessReturnType_OutParam, samples.Simple$__$Matrix.matrix, samples.Simple$__$Matrix.matrix, null, true, executeInfo.getErrorException(), new Pair<Object, Object>(AppSymbols_Label.Jill$__$Daniels, null));

			if (executeInfo.get_HadError() && executeInfo.containsError(ExecutionInfo.ErrorType.AbortAccess)) 
				throw new ExceptRuntime_MatrixAccessError("Was trying the first access of the Matrix named samples.Simple$__$Matrix.matrix but had an error. The annotation handler tried to process this error but was not able to.");

			if (accessReturnType_OutParam != null && accessReturnType_OutParam.returnType == AnnotationParameters.AccessReturnType.accessorValue)
				Descriptor__32__STATIC__LBL_Jill$__$Daniels = (Descriptor)annotateRetVal;
			else // accessReturnType_OutParam.returnType == AnnotationParameters.AccessReturnType.accessValue)
				return (Descriptor)annotateRetVal;
		}



		return Descriptor__32__STATIC__LBL_Jill$__$Daniels;

	}





	//  Continued Access
	public static String accessMatrix___24(ExecutionInfo executeInfo, Descriptor descriptor, SimpleEmbeddedFile__Annotations callerObj) {


		//  Static Field Access by Static Descriptor Tag Name, FirstName.
		if (DescriptorUtilities.validDescriptors(executeInfo, descriptor)) {
			try{
				if (descriptor.has_FieldSet()) {
					return ((samples.matrix.app.FieldSetTuple__samples$_CC_$Simple$__$Schema$_S_$PERSON)descriptor.get_FieldSet()).get_FirstName(executeInfo);
				} else {
					executeInfo.addErrorInfo(ExecutionInfo.ErrorType.AccessedFieldButNoFieldSetExists);
				}

			} catch (Exception e) {
				executeInfo.setErrorException(e);
			}

		} else { // end of if (validDescriptors())
			executeInfo.addErrorInfo(ExecutionInfo.ErrorType.AccessedDescriptorThatWasNotFound);
		}

		// Error handling code
		AnnotationParameters_AccessReturnType_OutParam accessReturnType_OutParam = new AnnotationParameters_AccessReturnType_OutParam();
		Object annotateRetVal = callerObj.annotationHandler_2(executeInfo, false, null, 0, 0, AnnotationParameters.AccessType.Field, accessReturnType_OutParam, descriptor, descriptor, null, true, executeInfo.getErrorException(), new Pair<Object, Object>(AppSymbols_DescTagName.FirstName, null));

		if (executeInfo.get_HadError() && executeInfo.containsError(ExecutionInfo.ErrorType.AbortAccess)) 
			throw new ExceptRuntime_MatrixAccessError("Was trying the first access of the Matrix named descriptor but had an error. The annotation handler tried to process this error but was not able to.");

		return (String)annotateRetVal;

	}





	//  Continued Access
	public static String accessMatrix___25(ExecutionInfo executeInfo, Descriptor descriptor, SimpleEmbeddedFile__Annotations callerObj) {


		//  Static Field Access by Static Descriptor Tag Name, LastName.
		if (DescriptorUtilities.validDescriptors(executeInfo, descriptor)) {
			try{
				if (descriptor.has_FieldSet()) {
					return ((samples.matrix.app.FieldSetTuple__samples$_CC_$Simple$__$Schema$_S_$PERSON)descriptor.get_FieldSet()).get_LastName(executeInfo);
				} else {
					executeInfo.addErrorInfo(ExecutionInfo.ErrorType.AccessedFieldButNoFieldSetExists);
				}

			} catch (Exception e) {
				executeInfo.setErrorException(e);
			}

		} else { // end of if (validDescriptors())
			executeInfo.addErrorInfo(ExecutionInfo.ErrorType.AccessedDescriptorThatWasNotFound);
		}

		// Error handling code
		AnnotationParameters_AccessReturnType_OutParam accessReturnType_OutParam = new AnnotationParameters_AccessReturnType_OutParam();
		Object annotateRetVal = callerObj.annotationHandler_2(executeInfo, false, null, 0, 0, AnnotationParameters.AccessType.Field, accessReturnType_OutParam, descriptor, descriptor, null, true, executeInfo.getErrorException(), new Pair<Object, Object>(AppSymbols_DescTagName.LastName, null));

		if (executeInfo.get_HadError() && executeInfo.containsError(ExecutionInfo.ErrorType.AbortAccess)) 
			throw new ExceptRuntime_MatrixAccessError("Was trying the first access of the Matrix named descriptor but had an error. The annotation handler tried to process this error but was not able to.");

		return (String)annotateRetVal;

	}





	//  Continued Access
	public static int accessMatrix___26(ExecutionInfo executeInfo, Descriptor descriptor, SimpleEmbeddedFile__Annotations callerObj) {


		//  Static Field Access by Static Descriptor Tag Name, Age.
		if (DescriptorUtilities.validDescriptors(executeInfo, descriptor)) {
			try{
				if (descriptor.has_FieldSet()) {
					return ((samples.matrix.app.FieldSetTuple__samples$_CC_$Simple$__$Schema$_S_$PERSON)descriptor.get_FieldSet()).get_Age(executeInfo);
				} else {
					executeInfo.addErrorInfo(ExecutionInfo.ErrorType.AccessedFieldButNoFieldSetExists);
				}

			} catch (Exception e) {
				executeInfo.setErrorException(e);
			}

		} else { // end of if (validDescriptors())
			executeInfo.addErrorInfo(ExecutionInfo.ErrorType.AccessedDescriptorThatWasNotFound);
		}

		// Error handling code
		AnnotationParameters_AccessReturnType_OutParam accessReturnType_OutParam = new AnnotationParameters_AccessReturnType_OutParam();
		Object annotateRetVal = callerObj.annotationHandler_2(executeInfo, false, null, 0, 0, AnnotationParameters.AccessType.Field, accessReturnType_OutParam, descriptor, descriptor, null, true, executeInfo.getErrorException(), new Pair<Object, Object>(AppSymbols_DescTagName.Age, null));

		if (executeInfo.get_HadError() && executeInfo.containsError(ExecutionInfo.ErrorType.AbortAccess)) 
			throw new ExceptRuntime_MatrixAccessError("Was trying the first access of the Matrix named descriptor but had an error. The annotation handler tried to process this error but was not able to.");

		return ((Integer)annotateRetVal).intValue();

	}






}
