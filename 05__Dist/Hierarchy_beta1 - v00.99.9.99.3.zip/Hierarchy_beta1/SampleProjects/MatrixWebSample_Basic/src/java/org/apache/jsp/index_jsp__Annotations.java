package org.apache.jsp;


import net . unconventionalthinking . matrix . * ;

import net.unconventionalthinking.exceptions.*;
import net.unconventionalthinking.matrix.*;
import net.unconventionalthinking.lang.*;
import net.unconventionalthinking.matrix.symbols.*;
import maintests . samples . * ;

import maintests.samples.AppSymbols_DescTagName;
import maintests.samples.AppSymbols_SchemaName;
import maintests.samples.AppSymbols;
import net . unconventionalthinking . lang . * ;

import maintests.samples.AppSymbols_DescTag;
import maintests.samples.AppSymbols_MatrixName;
import javax . servlet . * ;

import maintests.samples.AppSymbols_Label;
import javax . servlet . jsp . * ;

import net.unconventionalthinking.matrix.metacompiler.codegen.Exception_MetaCompilerError;
import net . unconventionalthinking . matrix . symbols . * ;

import javax . servlet . http . * ;

import maintests.samples.AppControl;




public interface index_jsp__Annotations {

	public Object annotationHandler_3(ExecutionInfo executeInfo, 
		boolean annotationReference_Exists, Symbol annotationRef_Base, int annotationRef_AccessCounter,
		int childAccessIndex, AnnotationParameters.AccessType accessType, AnnotationParameters_AccessReturnType_OutParam accessReturnType_OutParam, 
		Descriptor rootAccessDescriptor, Descriptor currAccessors_ParentDescriptor, MatrixSet<Descriptor> currAccessors_ParentDescriptorSet, 
		boolean passingInException, Exception e, Pair<Object, Object>... childAccessor_Pairs);



}
